const DEFAULT_HEADER = { "content-type": "text/html" };

module.exports = {
  DEFAULT_HEADER,
};
